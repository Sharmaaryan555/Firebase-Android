package com.example.myapplication.ui.theme

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.myapplication.R

import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth

class RegisterActivity : AppCompatActivity() {

    private lateinit var email:EditText;
    private lateinit var password :EditText;
    private lateinit var register: Button;

    private lateinit var auth:FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        email = findViewById(R.id.email)
        password = findViewById(R.id.password)
        register = findViewById(R.id.Register)

        auth = FirebaseAuth.getInstance()
        register.setOnClickListener{
          var txt_email:String = email.getText().toString();
            var txt_password:String = password.getText().toString();

            if (TextUtils.isEmpty(txt_email )|| TextUtils.isEmpty(txt_password)){
                Toast.makeText(this@RegisterActivity,"Empty Credientials",Toast.LENGTH_SHORT).show() }
            else if (txt_password.length <6){
                Toast.makeText(this@RegisterActivity,"Password to short ",Toast.LENGTH_SHORT).show()
            }
            else{
                registerUser(txt_email,txt_password);
                
            }
        }



    }

    private fun registerUser(email: String, password: String) {
    auth.createUserWithEmailAndPassword(email,password).addOnCompleteListener{
        if (it.isSuccessful){
            Toast.makeText(this@RegisterActivity,"Register user Successfully",Toast.LENGTH_SHORT).show()

        }
        else{
            Toast.makeText(this@RegisterActivity,"Register Failed",Toast.LENGTH_SHORT).show()
        }

    }
    }
}